const express = require("express");
const app = express();
const port = process.env.PORT || 5000;
const mongoose = require("mongoose");
const cors = require("cors");
const bodyParser = require("body-parser");
const cookieParser = require("cookie-parser"); // Correct middleware for handling cookies
const jwt = require("jsonwebtoken");
const multer = require("multer");
const bcrypt = require("bcrypt");
const path = require("path");
const fs = require("fs");
const User = require("./databaseconnections/models/User_register");
const Userproducts = require("./databaseconnections/models/newProducts");
const database = require("./databaseconnections/database"); // Assuming this file handles database connection
const nodemailer = require("nodemailer");
// Connect to the database

// Middleware setup
app.use(
  cors({
    origin: "*", // Allow requests from any origin
    methods: "GET,HEAD,PUT,PATCH,POST,DELETE", // Allow specified methods
    allowedHeaders: "Content-Type", // Allow specified headers
  })
);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cookieParser());

const uploadDirectory = path.join(__dirname, "uploads");
if (!fs.existsSync(uploadDirectory)) {
  fs.mkdirSync(uploadDirectory);
}

// Configure multer for handling file uploads
const storage = multer.diskStorage({
  destination: "./uploads/",
  filename: function (req, file, cb) {
    cb(
      null,
      file.fieldname + "-" + Date.now() + path.extname(file.originalname)
    );
  },
});

const upload = multer({ storage: storage });
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

app.get("/", (req, res) => {
  res.send("Hello World");
});

// Register route
app.post("/register", upload.single("image"), async (req, res) => {
  try {
    const {
      name,
      email,
      password,
      cpassword,
      phone,
      address,
      state,
      Zipcode,
      City,
    } = req.body;

    if (password !== cpassword) {
      return res.status(400).json({ error: "Passwords do not match" });
    }

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ error: "Email already exists" });
    }

    const user = new User({
      name,
      email,
      password,
      phone,
      address,
      state,
      Zipcode,
      City,
      image: req.file ? req.file.path : "",
    });

    await user.save();

    // const token = jwt.sign(
    //   { userId: user._id },
    //   process.env.JWT_SECRET || "thenaemischadnanshamacaslsldthenme",
    //   { expiresIn: "1h" }
    // );

    const token = await user.generateAuthToken();
    console.log("the token part is : " + token);
    res.cookie("jwt", token, {
      expires: new Date(Date.now() + 600000),
      httpOnly: true,
    });

    res.status(200).json({ message: "User created successfully" });
  } catch (error) {
    console.error("Error creating user: ", error);
    res.status(500).json({ error: "Failed to create user" });
  }
});

// Login route
app.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: "Please enter email and password" });
    }

    const user = await User.findOne({ email });
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(400).json({ error: "Invalid email or password" });
    }

    const token = jwt.sign(
      { userId: user._id },
      process.env.JWT_SECRET || "thenaemischadnanshamacaslsldthenme",
      { expiresIn: "1h" }
    );

    res.status(200).json({ message: "Success", token });
  } catch (error) {
    console.error("Error during login: ", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

// Route to get user details
app.get("/user_details", async (req, res) => {
  try {
    const details = await User.find();
    res.status(200).json(details);
  } catch (error) {
    console.error("Error fetching user details: ", error);
    res.status(500).json({ error: "Failed to fetch user details" });
  }
});

// Serve static files from the 'uploads' directory
app.use("/uploads", express.static(uploadDirectory));

//sendign the email to ther user if theu forgot password to reset the passord
const SECRET_KEY =
  process.env.SECRET_KEY ||
  "thenameischanansharmaclassnepalsecondaryschoolthename";

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "utamsharma57@gmail.com",
    pass: "dbsq lvct gjep lowe",
  },
});
app.post("/forgot_email", async (req, res) => {
  try {
    const { email } = req.body;

    //checking the if the email exist or not

    User.findOne({ email }).then((user) => {
      if (!user) {
        return res.status(400).json({ error: "email not exists" });
      }

      const token = jwt.sign({ id: user._id }, SECRET_KEY, { expiresIn: "1d" });

      const resetPasswordURL = `http://localhost:3000/Createpassword/${user._id}/${token}`;

      const mailOptions = {
        from: "utamsharma575757@gmail.com",
        to: email,
        subject: "Password Reset",
        text:
          `You are receiving this because you (or someone else) have requested the reset of the password for your account.\n\n` +
          `Please click on the following link, or paste it into your browser to complete the process:\n\n` +
          resetPasswordURL +
          "\n\n" +
          `If you did not request this, please ignore this email and your password will remain unchanged.\n`,
      };

      transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
          console.error(error);
          res.status(500).send("Failed to send email");
        } else {
          console.log("Email sent: " + info.response);
          res.status(200).send("Email sent successfully (if email exists)");
        }
      });
    });
  } catch (error) {
    console.log(error);
    res.status(400).json({ erro: "failed to sent email" });
  }
});

//changing the password

app.post("/createpassword/:id/:token", async (req, res) => {
  try {
    const { password } = req.body;
    const { id, token } = req.params;

    //method to verify the token

    const decode = jwt.verify(token, SECRET_KEY);

    if (decode.id !== id) {
      return res.status(400).json({ error: "token doesnot match user id" });
    }

    //hashing the password

    const hashing = await bcrypt.hash(password, 10);
    //now updating the user password

    const updateuse = await User.findByIdAndUpdate(
      id,
      { password: hashing },
      { new: true }
    );

    if (updateuse) {
      res.status(200).json({ message: "password updated sucess.." });
    } else {
      res.status(400).json({ error: "failed to update password" });
    }
  } catch (error) {
    console.error("Error updating password:", error);
    const errorMessage =
      error.name === "JsonWebTokenError"
        ? "Invalid or expired token"
        : "Failed to update password";
    return res.status(400).json({ message: errorMessage });
  }
});



app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
