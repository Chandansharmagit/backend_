// models/User.js
const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
 
  cart: [
    {
      productId: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
      name: String,
      price: Number,
      desc: String,
      img: String, // Added image path here
      quantity: Number,
    },
  ],
});

const Userproducts = mongoose.model('Userproducts', userSchema);

module.exports = Userproducts;
